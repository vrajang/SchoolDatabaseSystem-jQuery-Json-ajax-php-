<?php

//I, VRAJANG SHAH, student 000826893, certify that this material is my original work. No other person's work has been used without due acknowledgment 
//and I have not made my work available to anyone else.
//this file save all the new enterd items in the database and shows in the shopping list
include "connect02.php";

$servername = "localhost";
$username = "root";
$password="";
$dbname="class2";
// Creating  connection
$conn = new mysqli($servername, $username,$password,$dbname);
// Checking connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$newsql = "INSERT INTO `class2`(`id`, `firstname`, `rollnb`, `percentage`) VALUES ('".$_GET['id']."','".$_GET["name"]."','".$_GET["rollnb"]."','".$_GET['per']."')";
 
if($conn->query($newsql) === true){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $newsql. " . $conn->error;
}	
       



$conn->close();
?>
<!DOCTYPE html>

<html>
 
<head>
    <title>CLASS 2</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/ajaxexamples.css">
    <script src="js2/getjson.js"></script>
</head>

<body>
    <div id="container">
        <div id="header">
            <h1>CLASS 2</h1>
            <h2>professor: MIHAI</h2>
        </div>
        <div id="body">
            <form action="save02.php" method="GET">
            <label>:::::Add new Students Record::::::</label>  <br><br>
            <label type="id"  >ENROLLMENT ID:</label>
            <input type="number" name="id" value=""><br>
            <label type="item"  >NAME:</label>
            <input type="text" name="name" value=""><br>
            <label type="quantity"  >ROLLNO:</label>
            <input type="number" name="rollnb" value="10"><br>
            <label type="price"  >PERCENTAGE:</label>
            <input type="number" name="per" value="5"><br>
            
            <input type="submit" id="ADD" value="ADD STUDENTS">
            </form>
        </div>

        <div id="body">
            <label>:::::::Students Enrolled::::::</label><br><br>
            <input type="button" id="clickme02" value="SHOW STUDENTS">
            <span id="target">
            <br><br>
           <label>ID    &nbsp;&nbsp;     :NAME       &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;    :ROLLNO  &nbsp;&nbsp; &nbsp;&nbsp;     :PERCENTAGE</label>


            </span>
            <div id="students"></div>
        </div>
    </div>
</body>

</html>
