//I, VRAJANG SHAH, student 000826893, certify that this material is my original work. No other person's work has been used without due acknowledgment 
//and I have not made my work available to anyone else.
//this file save all the new enterd items in the database and shows in the shopping list

jQuery("#backtotop").click(function () {
    jQuery("body,html").animate({
        scrollTop: 0
    }, 600);
});
jQuery(window).scroll(function () {
    if (jQuery(window).scrollTop() > 150) {
        jQuery("#backtotop").addClass("visible");
    } else {
        jQuery("#backtotop").removeClass("visible");
    }
});