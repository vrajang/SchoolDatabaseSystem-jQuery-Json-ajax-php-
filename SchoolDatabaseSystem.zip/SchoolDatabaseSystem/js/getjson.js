//I, VRAJANG SHAH, student 000826893, certify that this material is my original work. No other person's work has been used without due acknowledgment 
//and I have not made my work available to anyone else.
window.addEventListener("load", function() {

    /**
     * Gets a user object and converts it to HTML for inclusion on the page.
     * @param {User} user 
     */
    function userToHtml(user) {
        let html = "<div>";
        html += "<h3>" + user.id + ": &nbsp&nbsp  " + user.firstname  +": &nbsp&nbsp"  + user.rollnb +  ": &nbsp&nbsp     "  + user.percentage2+  "%</h3>";
        
        html += "</div>";
        return html;
    }
    /**
     * This function should be called when the AJAX call is complete
     * and the json-encoded array has been extracted from the response.
     * @param {Array} users
     */
    function success(users) {
        
        for (let i = 0; i < users.length; i++) {
            students += userToHtml(users[i]);
            
        }
       
        let span = document.getElementById("target");
        
       document.getElementById("students").innerHTML = students;

        console.log(users); // debug
    }

    let button = document.getElementById("clickme");
    button.addEventListener("click", function() {

        
        let url = "server/userlist.php";
        

        console.log(url); // debug

        // do the fetch
        fetch(url, { credentials: 'include' })
            .then(response => response.json())
            .then(success)
    });
});