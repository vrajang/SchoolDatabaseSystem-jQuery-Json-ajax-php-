<?php
// Initialize the session
//I, VRAJANG SHAH, student 000826893, certify that this material is my original work. No other person's work has been used without due acknowledgment 
//and I have not made my work available to anyone else.
//this file save all the new enterd items in the database and shows in the shopping list
session_start();
 
// Unset all of the session variables
$_SESSION = array();
 
// Destroy the session.
session_destroy();
 
// Redirect to login page
header("location: login.php");
exit;
?>