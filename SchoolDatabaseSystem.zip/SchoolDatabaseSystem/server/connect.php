<?php
//I, VRAJANG SHAH, student 000826893, certify that this material is my original work. No other person's work has been used without due acknowledgment 
//and I have not made my work available to anyone else.

try{
$dbh = new PDO(
        "mysql:host=localhost;dbname=class1",
        "root", 
        ""
);
}
catch(Exeption $e){
        die("error:couldnt connect.{$e->getmessage()}");
}


?>