<?php
//I, VRAJANG SHAH, student 000826893, certify that this material is my original work. No other person's work has been used without due acknowledgment 
//and I have not made my work available to anyone else.
//this file save all the new enterd items in the database and shows in the shopping list
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
 <!DOCTYPE html>

<html>
<head>
<title> SCHOOL DATABASE</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">

<script language="JavaScript" src="js/user.js">
</script>

</head>
<body id="top">

<div class="wrapper row0">
  <div id="topbar" class="hoc clear"> 
   
    <div class="fl_left">
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a></li>
        <li><a class="faicon-pinterest" href="https://uk.pinterest.com/"><i class="fa fa-pinterest"></i></a></li>
        <li><a class="faicon-twitter" href="https://twitter.com/"><i class="fa fa-twitter"></i></a></li>
        <li><a class="faicon-dribble" href="https://dribbble.com/"><i class="fa fa-dribbble"></i></a></li>
        <li><a class="faicon-linkedin" href="https://www.linkedin.com/"><i class="fa fa-linkedin"></i></a></li>
        <li><a class="faicon-google-plus" href="https://plus.google.com/"><i class="fa fa-google-plus"></i></a></li>
        <li><a class="faicon-rss" href="https://www.rss.com/"><i class="fa fa-rss"></i></a></li>
      </ul>
    </div>
    <div class="fl_right">
      <ul class="nospace inline pushright">
        <li><i class="fa fa-phone"></i> +1 647 615 5255</li>
        <li><i class="fa fa-envelope-o"></i> westerncollege12@gmail.com </li>
      </ul>
    </div>
  
  </div>
</div>

<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
   
    <div id="logo" class="fl_left">
      <h1><a href="https://www.mohawkcollege.ca/">WESTERN SCHOOL OF ONTARIO</a></h1>
    </div>
 
  </header>
</div>


<div class="wrapper bgded overlay" style="background-image:url('images/demo/backgrounds/background1.jpg');">
  <section id="testimonials" class="hoc container clear"> 

    <h2 class="font-x3 uppercase btmspace-80 underlined"> SCHOOL <a href="#">DATABASE</a></h2>
    <ul class="nospace group">
       <h3 align="right"> <a href="index.php" class="btnbtn-primary" align ="right">Class 1</a><br></h3>
       <h3 align="right"> <a href="index02.php" class="btnbtn-primary">Class 2</a><br><br></h3>
       <h3 align="right"><a href="logout.php" class="btnbtn-primarylogout" align="right">Sign Out of Your Account</a></h3>
      <li class="one_half">
        <blockquote>In "SCHOOL DATABASE SYSTEM" we use to collect all the data of each individual students with their names ,id ,roll number and 
     percentage . Moreover , you can also add the new students by entering all the new data in their respective boxes. To access the class simply click on rspective class name.  </blockquote>
      
      </li>
    </ul>

  </section>
</div>

<div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 

    <div class="one_third first">
      <h6 class="title">Address</h6>
      <ul class="nospace linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
         
          <p>
          Address     : 135 Fennell Ave W, <br>
          CITY        : Hamilton <br>
          PROVINCE    : ON <br>
          POSTAL CODE : L9C 0E5 <br>
          </p>
          </address>
        </li>
      </ul>
    </div>

    <div class="one_third">
      <h6 class="title">Phone</h6>
      <ul class="nospace linklist contact">
       
        <li><i class="fa fa-phone"></i> +(905) 575-1212<br>
          +1-844-767-6871</li>


      </ul>
    </div>

    <div class="one_third">
      <h6 class="title">Email</h6>
      <ul class="nospace linklist contact">
        
        <li><i class="fa fa-envelope-o"></i> westerncollege12@gmail.com </li>

      </ul>
    </div>


  </footer>
</div>

  <div id="copyright" class="hoc clear"> 

    <p class="fl_left"><a href="#">VRAJANG SHAH (000826893)</a></p>
    <p class="fl_right">E-mail <a target="_blank" h>vrajang10@gmail.com</a></p>
    
  </div>
</div>

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="layout/scripts/jquery.min.js"></script>
<script src="layout/scripts/jquery.backtotop.js"></script>
<script src="layout/scripts/jquery.mobilemenu.js"></script>
<script src="layout/scripts/jquery.placeholder.min.js"></script>

</body>
</html>


