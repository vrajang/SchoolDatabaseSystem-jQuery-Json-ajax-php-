<?php
//I, VRAJANG SHAH, student 000826893, certify that this material is my original work. No other person's work has been used without due acknowledgment 
//and I have not made my work available to anyone else.
//this file save all the new enterd items in the database and shows in the shopping list
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'user');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>