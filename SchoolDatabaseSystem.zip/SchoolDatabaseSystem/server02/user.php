<?php
//I, VRAJANG SHAH, student 000826893, certify that this material is my original work. No other person's work has been used without due acknowledgment 
//and I have not made my work available to anyone else.
class User implements JsonSerializable
{
    private $id;
    private $firstname;
    private $rollnb;
    private $percentage;

    function __construct($id,$firstname,$rollnb,$percentage)
    {
        $this->id = (int)$id;
        $this->firstname = $firstname;
        $this->rollnb = (int)$rollnb;
        $this->percentage = (int)$percentage;

    }

    /**
     * Returns a string representation of the user object as a list item
     */
    function toListItem()
    {
        return "<li>$this->id $this->firstname</li>";
    }

    /**
     * Called by json_encode  
     */
    public function jsonSerialize()
    {
        return  get_object_vars($this);
    }
}
